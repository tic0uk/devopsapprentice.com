---
title: Contact
layout: page
---

You can always contact the creator of this theme via [Twitter](https://twitter.com/_SupunKavinda).

If you need help with Jekyll, ask questions on [Jekyll Talk](https://talk.jekyllrb.com/).

(Change this by editing `contact.md` file)